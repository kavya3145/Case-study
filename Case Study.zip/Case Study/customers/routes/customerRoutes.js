var express = require('express');
var router = express.Router();
var customerController=require('../controller/customersController')

router.get('/test', customerController.test);
router.post('/register', customerController.saveCustomer);
router.post('/login', customerController.loginCustomer);

module.exports = router;
