const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const config = require('./config/mongoose.js');

mongoose.connect(config.url, {
    useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

const app = express();
app.use(bodyParser.json());
var customerRoutes=require('./routes/customerRoutes');

//Rest Endpoints
app.use('/customers',customerRoutes);

//port number
const PORT = process.env.PORT || 3000;

app.listen(PORT,() => {
    console.log('Customer App Listening in Port: '+PORT)

})
