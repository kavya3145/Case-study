const express=require('express');
var bcrypt = require('bcrypt-nodejs');
const Customer =require('../model/customer.js');


function test(req, res) {
    res.status(200).send({
        message: 'testing customer controller action'
    });
}

function saveCustomer(req, res) {
    var customer = new Customer();

    var params = req.body;

    console.log(params);

    customer.firstName = params.firstName;
    customer.lastName = params.lastName;
    customer.email = params.email;
    // user.confirmpassword = 'null';


    if (params.password) {
        //encript password and save data
        bcrypt.hash(params.password, null, null, function(err, hash) {
            customer.password = hash;
            console.log(customer);

            if (customer.firstName != null && customer.lastName != null && customer.email != null) {
                customer.save((err, customerStored) => {
                    if (err) {
                        res.status(500).send({
                            message: 'Error trying to save the customer'
                        });
                    } else {
                        if (!customerStored) {
                            res.status(404).send({
                                message: 'Customer could not be saved'
                            });
                        } else {
                            res.status(200).send({
                                customer: customerStored
                            });
                        }
                    }
                })
            } else {
                res.status(200).send({
                    message: 'Every input is required'
                });
            }
        })
    } else {
        res.status(200).send({
            message: 'Password is required'
        });
    }
}

function loginCustomer(req, res) {
    var params = req.body;

    var email = params.email;
    var password = params.password;

    Customer.findOne(
        {email: email.toLowerCase()},
        (err, customer) => {
            if(err) {
                res.status(500).send({
                    message: 'Request Error'
                });
            } else {
                if(!customer) {
                    res.status(404).send({
                        message: 'Customer does not exist'
                    });
                } else {
                    bcrypt.compare(password, customer.password, function(err, check) {
                        if(check) {
                            //return customer logged
                            if(params.gethash) {
                                //return jwt token
                            } else {
                                res.status(200).send({
                                    customer
                                });
                            }
                        } else {
                            res.status(404).send({
                                message: 'Customer could not log'
                            });
                        }
                    })
                }
            }
        } 
    );
}


module.exports = {
    test,
    saveCustomer,
    loginCustomer
}